-- Run after running the disposable-copy migration a second time.
-- WARNING: SQL cannot independently prove the active Supabase project identity.
-- Verify Dashboard URL and Project Settings > General show ifakxmugmdcjyhytzpwx
-- before every script. Never use production ref bupageguxdvphaebvdoa.
do $assertions$
declare
  v_configured_ref constant text := 'ifakxmugmdcjyhytzpwx';
begin
  if v_configured_ref <> 'ifakxmugmdcjyhytzpwx'
     or not exists (
    select 1 from public.cms_validation_scope
    where scope_name = 'portfolio-cms-migration-test'
      and verified_project_ref = 'ifakxmugmdcjyhytzpwx'
  ) then
    raise exception 'STOP: disposable-project marker/ref mismatch.';
  end if;
  if not exists (
    select 1 from public.portfolio_cms_records
    where content_type = 'projects'
      and record_id = 'validation-rerun-sentinel'
      and status = 'draft'
      and revision = 7
      and draft_payload = '{"title":"CMS sentinel","visibility":false}'::jsonb
      and published_payload is null
  ) then
    raise exception 'FAIL: migration rerun changed or deleted the CMS sentinel.';
  end if;
  if not exists (
    select 1 from public.portfolio_cms_public_records
    where content_type = 'projects'
      and record_id = 'validation-rerun-sentinel'
      and published_payload = '{"title":"Projection sentinel - preserve exactly","visibility":true,"sentinel":731}'::jsonb
  ) then
    raise exception 'FAIL: migration rerun changed or deleted the existing public projection sentinel.';
  end if;
  if exists (
    select 1 from public.cms_validation_bucket_baseline baseline
    join storage.buckets bucket on bucket.id = baseline.bucket_id
    where bucket.public is distinct from baseline.was_public
  ) then
    raise exception 'FAIL: migration rerun changed legacy bucket visibility.';
  end if;
  if exists (
    select 1 from public.cms_validation_destination_baseline baseline
    join storage.buckets bucket on bucket.id = baseline.bucket_id
    where bucket.name is distinct from baseline.name
       or bucket.public is distinct from baseline.was_public
       or bucket.file_size_limit is distinct from baseline.file_size_limit
       or bucket.allowed_mime_types is distinct from baseline.allowed_mime_types
  ) then
    raise exception 'FAIL: migration rerun changed CMS destination bucket metadata.';
  end if;
end;
$assertions$;

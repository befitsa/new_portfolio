-- Run after 01_post_migration_assertions.sql and before re-running the migration.
-- This creates intentional sentinel rows only in the disposable test database.
-- WARNING: SQL cannot independently prove the active Supabase project identity.
-- Verify Dashboard URL and Project Settings > General show ifakxmugmdcjyhytzpwx
-- before every script. Never use production ref bupageguxdvphaebvdoa.
do $seed$
declare
  v_configured_ref constant text := 'ifakxmugmdcjyhytzpwx';
begin
  if v_configured_ref <> 'ifakxmugmdcjyhytzpwx'
     or not exists (
       select 1 from public.cms_validation_scope
       where scope_name = 'portfolio-cms-migration-test'
         and verified_project_ref = 'ifakxmugmdcjyhytzpwx'
     ) then
    raise exception 'STOP: disposable-project marker/ref mismatch.';
  end if;
  if exists (
    select 1 from public.portfolio_cms_records
    where content_type = 'projects' and record_id = 'validation-rerun-sentinel'
  ) then
    raise exception 'STOP: rerun sentinel already exists; do not overwrite it.';
  end if;
end;
$seed$;

create table public.cms_validation_destination_baseline (
  bucket_id text primary key,
  name text not null,
  was_public boolean not null,
  file_size_limit bigint,
  allowed_mime_types text[]
);
insert into public.cms_validation_destination_baseline (
  bucket_id, name, was_public, file_size_limit, allowed_mime_types
)
select id, name, public, file_size_limit, allowed_mime_types from storage.buckets
where id in ('portfolio-private', 'portfolio-published');

do $empty_destinations$
begin
  if (select count(*) from public.cms_validation_destination_baseline) <> 2
     or exists (
       select 1 from storage.objects
       where bucket_id in ('portfolio-private', 'portfolio-published')
     ) then
    raise exception 'STOP: expected both empty CMS test buckets; use a fresh disposable project.';
  end if;
  if exists (
    select 1 from public.cms_validation_destination_baseline
    where bucket_id in ('portfolio-private', 'portfolio-published')
      and was_public
  ) then
    raise exception 'STOP: both CMS destination buckets must already be private for this rerun test; do not change their visibility here.';
  end if;
end;
$empty_destinations$;

insert into public.portfolio_cms_records (
  content_type, record_id, status, draft_payload,
  revision, published_revision, base_published_revision
) values (
  'projects', 'validation-rerun-sentinel', 'draft',
  '{"title":"CMS sentinel","visibility":false}'::jsonb,
  7, 7, 7
);

-- Deliberately differs from the CMS row: the migration must preserve it via
-- ON CONFLICT DO NOTHING rather than refresh/overwrite the existing projection.
insert into public.portfolio_cms_public_records (
  content_type, record_id, published_payload
) values (
  'projects', 'validation-rerun-sentinel',
  '{"title":"Projection sentinel - preserve exactly","visibility":true,"sentinel":731}'::jsonb
);

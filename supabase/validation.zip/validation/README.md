# Hosted Supabase migration validation (review-only)

These are disposable-project validation scripts, not migrations. Do not copy
them into `supabase/migrations`. No SQL in this workflow has been executed.

## Critical target-project safeguard

> **The only permitted hosted test project is `ifakxmugmdcjyhytzpwx`. Never run
> these scripts or the disposable-copy migration against production project
> `bupageguxdvphaebvdoa`. SQL cannot independently prove which Supabase project
> is active in the SQL Editor.**

Before **every** script, manually verify that both the Supabase Dashboard URL
and **Project Settings > General** show exactly `ifakxmugmdcjyhytzpwx`. If
either is unavailable, differs, or is ambiguous, stop without running SQL.
Each SQL script contains the expected ref as a fixed marker and checks that
`cms_validation_scope.verified_project_ref` matches it. This catches an
incorrect script marker or setup sequence; it does **not** identify or
authenticate the remote project, and is not a substitute for the manual
Dashboard check.

Do not use production credentials, data, publishable keys, service-role keys,
database passwords, or connection strings. Do not link the repository, deploy,
or run `supabase db push`.

## Disposable-copy migration

The repository migration contains the production administrator UID. Make a
separate temporary text copy and replace every occurrence of
`350db73c-d045-4b51-88bf-36ee9b2d07db` with the fake UID
`11111111-1111-4111-8111-111111111111`. Do not modify the repository migration
for this workflow. The setup script registers only that fake UID. Before
pasting the copied migration, repeat the Dashboard URL and Project Settings >
General check for exact ref `ifakxmugmdcjyhytzpwx`.

## Run order

Use only the newly-created, empty disposable project whose verified ref is
exactly `ifakxmugmdcjyhytzpwx`. Stop if it already contains CMS tables,
prerequisite/legacy tables, or any of the fixture bucket IDs. Do not repurpose
a project with data.

1. Manually verify the exact project ref in the Dashboard URL and Project
   Settings > General. SQL cannot independently verify the active target.
2. Run [00_setup.sql](./00_setup.sql) once. It checks Supabase Auth/Storage
   prerequisites and object-name collisions before creating fake test
   prerequisites, legacy fixtures, and empty legacy bucket fixtures.
3. Paste/run the disposable-copy migration described above in that verified
   project's SQL Editor.
4. Run [01_post_migration_assertions.sql](./01_post_migration_assertions.sql).
   It checks created CMS objects, conservative legacy backfill, distinct bucket
   IDs, and the expected blocked/private initial publication state.
5. Run [02_rerun_seed.sql](./02_rerun_seed.sql), paste/run the same
   disposable-copy migration a second time, then run
   [03_rerun_assertions.sql](./03_rerun_assertions.sql). The seed records
   existing destination bucket metadata and creates CMS/projection sentinels.
   It does not change bucket visibility. Both destination buckets must be
   private and empty at this stage. The assertion checks CMS data, projection,
   legacy bucket, and destination bucket metadata preservation.
6. Run [04_security_and_bucket_scenarios.sql](./04_security_and_bucket_scenarios.sql).
   It checks storage path parsing, direct RPC readiness enforcement,
   non-admin authorization, audit-table protection, and draft privacy. It
   changes only temporary CMS test rows inside a transaction and ends with
   `ROLLBACK`. It does not test a public destination state or successful
   publication; no script changes bucket visibility to reach those states.
7. For [05_dotted_object_assertion.sql](./05_dotted_object_assertion.sql),
   upload one harmless, non-sensitive text file through the disposable
   project's Storage Dashboard to the exact bucket ID `portfolio-media.`
   (including the trailing period). This legacy fixture is public, so the file
   may be publicly accessible while present. Run the assertion, then
   immediately delete that exact test object in the Dashboard and verify the
   dotted bucket is empty. Do not upload sensitive content. This is the only
   workflow step that creates a Storage object; never insert, update, or delete
   rows directly in `storage.objects`.

If SQL Editor does not permit the role/claim simulation, record that test as
not run. Do not weaken policies to make a script pass. A successful SQL Editor
run proves only the assertions actually executed.

## Bucket visibility and rerun scope

No validation script updates an existing bucket's `public` flag. The setup
creates only absent, empty fixture buckets; the dotted and hyphenated legacy
fixtures are intentionally public and empty, while `portfolio_media` is
private. The migration's two destination bucket upserts can be statically
reviewed: their `ON CONFLICT` update lists must not assign `public`. The rerun
assertions compare stored destination metadata without changing it.

The harness deliberately does not dynamically test an already-public
`portfolio-published` conflict case. Doing that safely would require a
pre-existing public bucket, careful proof that it is empty, and a separate
isolated scenario. Do not make any bucket public merely to complete this test
plan. The migration and its upsert clauses still require static review, and
hosted PostgreSQL validation remains pending until scripts are actually run
against the exact disposable project.

## Hosted-only behavior that cannot be fully simulated here

- The hosted project's Auth, Storage, API roles, PostgreSQL version,
  extensions, grants, publication configuration, and Storage implementation
  may differ from local Supabase or production.
- The setup does not create Auth users or test sign-in/password/email flows.
  `SET ROLE` plus `request.jwt.claims` simulates role/RLS/`auth.uid()` behavior;
  it is not a signed Auth JWT or a complete PostgREST integration test.
- Storage object presence is queried from the hosted `storage.objects` table.
  Object creation/deletion is performed via the Dashboard only. Public HTTP
  downloads, signed URLs, copy/delete failure behavior, and browser upload
  progress require separate client/API tests.
- Realtime publication enrollment is conditional in the migration. These
  scripts do not prove hosted Realtime delivery.
- JavaScript rollback tests use a mock client and cannot prove remote Storage
  API behavior under real partial failures.
- This workflow does not establish that production has the same schema or
  bucket states. Never run this test harness against production.
